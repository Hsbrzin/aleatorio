from pyrogram import Client, filters
from pyrogram.types import (
    CallbackQuery,
    ForceReply,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
)

from database import cur, save
from utils import get_info_wallet



@Client.on_callback_query(filters.regex(r"^user_info$"))
async def user_info(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
				 InlineKeyboardButton("💳 Histórico", callback_data="buy_history"),
			],
			[
				 InlineKeyboardButton("⚖️ Trocar Pontos", callback_data="swap"),
			     InlineKeyboardButton("💠 Dados Pix", callback_data="swap_info"),
			],
		    [
				 InlineKeyboardButton("🔗 Indicação", callback_data="indica"),
                 InlineKeyboardButton("🔙 Voltar", callback_data="start"),
            ],

        ]
    )
    
    await m.edit_message_text(
        f"""<b><a href='https://i.im.ge/2023/10/29/tH1JAh.IMG-20231028-093647-134.jpg'>&#8204</a></a>👥 <b>| Escolha a opção abaixo para vizualizar as informações quê você deseja:</b>""",
        reply_markup=kb,
    )
    
@Client.on_callback_query(filters.regex(r"^indica$"))
async def gift(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            
            
             [
                 InlineKeyboardButton("🔙 Voltar", callback_data="user_info"),
             ],

        ]
    )
    link = f"https://t.me/{c.me.username}?start={m.from_user.id}"
    await m.edit_message_text(
        f"""<b>💰 - Ao indicar você ganha saldo bônus por cada usuário que entrar pelo seu link!

• Cada usuário que der /start você ganha 1 real de saldo!
• O saldo pode usado para comprar ou apostar!"!

⚠️ - Função ainda sendo testada, pois quaisquer erro que for encontrado envie ao dev!

♦ Link para divulgação:</b> <code>{link}</code>""",
        reply_markup=kb,
    )
@Client.on_callback_query(filters.regex(r"dv$"))
async def dv(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("❮ ❮", callback_data="user_info"),
            ],
             [
                 InlineKeyboardButton("⚜️ Alugue Seu Bot", url="https://t.me/DAVIZIN7SIX"),
             ],
        ]
    )

    await m.edit_message_text(
        f"""[ ](https://i.ibb.co/t4sWF1S/Python-para-An-lise-de-Dados.webp)<b><b>⚙️ | Versão do bot: 2.5</b>

<b> ➤ Ultima atualização: 07/05/2023 </b>

<b> ➤ Sistema Automatico De Banimentos </b>

<b> ➤ Checker Privado com mais de 10 Opções </b>

<b> ➤ Sistema com Auto Reiniciamento </b>

<b> ➤ Sistema Atualizado com gifts </b>

<b> ➤ Opção de compra em Quantidade </b>

<b> ➤ Sistema de Pontos </b>

<b> ➤ Sistema de Cashback </b>

<b> ➤ Sistema de Referência </b>

<b> ➤ Pix com MP e Pagseguro </b>

<b> ➤ Mude o Pix com 1 Click </b>

<b> ➤ Sistema de ADMIN completo </b>


<b> ✅ | Bot by: @DAVIZIN7SIX </b>""",
  reply_markup=kb,
    )

@Client.on_callback_query(filters.regex(r"^pesquisar$"))
async def comprar_cc_list(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    "🔐 Buscar Bin",
                    switch_inline_query_current_chat="buscar_bin 550209",
                ),
                InlineKeyboardButton(
                    "🏦 Buscar Banco",
                    switch_inline_query_current_chat="buscar_banco BANCO",
                ),
            ],
            [
                InlineKeyboardButton(
                    "🏳️ Buscar Bandeira",
                    switch_inline_query_current_chat="buscar_bandeira MASTERCARD",
                ),
            ],
            [
                InlineKeyboardButton("🔙 Voltar", callback_data="comprar_cc"),
            ],
        ]
    )
    
    await m.edit_message_text(
        f"""<b><a href='https://i.im.ge/2023/10/28/tzxpKJ.IMG-20231028-071350-614.jpg'>&#8204</a></a>💳 <b>Pesquisar GG</b>
<i>- Escolha abaixo o produto que deseja comprar.""",
        reply_markup=kb,
    )
    

@Client.on_callback_query(filters.regex(r"^buy_history$"))
async def buy_history(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("🔙 Voltar", callback_data="user_info"),
            ],
        ]
    )
    history = cur.execute(
        "SELECT number, month, year, cvv FROM cards_sold WHERE owner = ? ORDER BY bought_date DESC LIMIT 50",
        [m.from_user.id],
    ).fetchall()

    if not history:
        cards_txt = "<b>⚠️ Não há nenhuma compra nos Registros.</b>"
    else:
        cards = []
        for card in history:
            cards.append("|".join([i for i in card]))
        cards_txt = "\n".join([f"<code>{cds}</code>" for cds in cards])

    await m.edit_message_text(
        f"""<b><a href='https://i.im.ge/2023/10/28/tzxpKJ.IMG-20231028-071350-614.jpg'>&#8204</a></a>💳 <b>Histórico de compras</b>
<i>- Histórico das ultimas compras.</i>

{cards_txt}""",
        reply_markup=kb,
    )


@Client.on_callback_query(filters.regex(r"^swap$"))
async def swap_points(c: Client, m: CallbackQuery):
    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("🔙 Voltar", callback_data="user_info"),
            ],
        ]
    )

    user_id = m.from_user.id
    balance, diamonds = cur.execute(
        "SELECT balance, balance_diamonds FROM users WHERE id=?", [user_id]
    ).fetchone()

    if diamonds >= 50:
        add_saldo = round((diamonds / 2), 2)
        new_balance = round((balance + add_saldo), 2)

        txt = f"⚜️ Seus <b>{diamonds}</b> pontos foram convertidos em R$ <b>{add_saldo}</b> de saldo."

        cur.execute(
            "UPDATE users SET balance = ?, balance_diamonds=?  WHERE id = ?",
            [new_balance, 0, user_id],
        )
        return await m.edit_message_text(txt, reply_markup=kb)

    await m.answer(
        "⚠️ Você não tem pontos suficientes para realizar a troca. O mínimo é 100 pontos.",
        show_alert=True,
    )


@Client.on_callback_query(filters.regex(r"^swap_info$"))
async def swap_info(c: Client, m: CallbackQuery):
    await m.message.delete()

    cpf = await m.message.ask(
        "<b>👤 CPF da lara (exemplo: 30599385120)</b>",
        reply_markup=ForceReply(),
        timeout=120,
    )
    name = await m.message.ask(
        "<b>👤 Nome completo do pagador (exemplo: wilma bernadete de almeida borba)</b>", reply_markup=ForceReply(), timeout=120
    )
    email = await m.message.ask(
        "<b>📧 E-mail (exemplo: soucorno@gmail.com)</b>", reply_markup=ForceReply(), timeout=120
    )
    cpf, name, email = cpf.text, name.text, email.text
    cur.execute(
        "UPDATE users SET cpf = ?, name = ?, email = ?  WHERE id = ?",
        [cpf, name, email, m.from_user.id],
    )
    save()

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton("🔙 Voltar", callback_data="user_info"),
            ]
        ]
    )
    await m.message.reply_text(
        "<b> ✅ Seus dados foram alterados com sucesso.</b>", reply_markup=kb
    )
