from typing import Union

from pyrogram import Client, filters
from pyrogram.errors import BadRequest
from pyrogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from database import cur, save
from utils import create_mention, get_info_wallet

import datetime
from typing import Union
import asyncio

@Client.on_message(filters.command(["start", "menu"]))
@Client.on_callback_query(filters.regex("^start$"))
async def start(c: Client, m: Union[Message, CallbackQuery]):
    user_id = m.from_user.id

    rt = cur.execute(
        "SELECT id, balance, balance_diamonds, refer FROM users WHERE id=?", [user_id]
    ).fetchone()
    
    # Check if user is registering for the first time
    if rt is None:
        cur.execute("INSERT INTO users (id, balance) VALUES (?, 2)", [user_id])

    if isinstance(m, Message):
        refer = (
            int(m.command[1])
            if (len(m.command) == 2)
            and (m.command[1]).isdigit()
            and int(m.command[1]) != user_id
            else None
        )

        if rt[3] is None:
            if refer is not None:
                mention = create_mention(m.from_user, with_id=False)

                cur.execute("UPDATE users SET refer = ? WHERE id = ?", [refer, user_id])
                try:
                    await c.send_message(
                        refer,
                        text=f"<b>🎁 Parabéns, o usuário {mention} se vinculou com seu link de afiliado e você receberá uma porcentagem do que o mesmo adicionar no nosso bot, e de brinde ambos ganharam 1 de saldo na store!</b>",
                    )
                    cur.execute("UPDATE users SET balance = balance + 1 WHERE id = ?", [refer])
                    cur.execute("UPDATE users SET balance = balance + 1 WHERE id = ?", [user_id])
                except BadRequest:
                    pass

    hora_atual = datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=-3)))

    hora_atual_str = hora_atual.strftime('%H:%M:%S')

    data_atual = datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=-3)))

    data_atual_str = data_atual.strftime('%d/%m/%Y')
	
    kb = InlineKeyboardMarkup(
        inline_keyboard=[

             [
                InlineKeyboardButton("💳 Cards", callback_data="comprar_cc"),
                InlineKeyboardButton("🏦 Laras", callback_data="comprar_laras"),
             ],
             [
			    InlineKeyboardButton("💠 Comprar Saldo", callback_data="add_saldo"),
                InlineKeyboardButton("👾 Carteira", callback_data="user_info"),
             ],
             [
				 InlineKeyboardButton("🏆 Ranking", callback_data="ranking"),
             ],
             [
                InlineKeyboardButton("💡 Atendimento", url="t.me/Barretofc"),
                InlineKeyboardButton("🛠 Atualizações", url="t.me/ChatBarreto"),
             ],
        ]
    )

    bot_logo, news_channel, support_user = cur.execute(
        "SELECT main_img, channel_user, support_user FROM bot_config WHERE ROWID = 0"
    ).fetchone()

    start_message = f"""<a href="https://i.im.ge/2023/10/27/tWH7pF.IMG-20231027-073822.jpg">📚</a> <b> | Olá bem vindo a melhor loja de ccs do mercado atualmente. So aqui você encontra o melhor material pelo melhor preço!!

💠 - Para por saldo use o /pix 10!!
✅ - 10 min para troca pelo bot ou pv!!
⚠️ - Dúvidas ou problemas fale com o suporte ativo das 07h as 22h!!

⎾🛍 | Saldo em dobro: Desativado 
⎿🕒 | Hora: {hora_atual_str}
    
🥇 | Suporte: @Boss_Original
👥 | Grupo: @null
👨‍💻 | Dev: @Boss_Original

{get_info_wallet(user_id)}</b> """

    if isinstance(m, CallbackQuery):
        send = m.edit_message_text
    else:
        send = m.reply_text
    save()
    await send(start_message, reply_markup=kb)